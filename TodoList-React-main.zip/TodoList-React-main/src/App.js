import React from 'react'
import TodoList from './Components/TodoList';
function App() {
  return (
    <div>
     <TodoList/>
    </div>
  );
}

export default App;
